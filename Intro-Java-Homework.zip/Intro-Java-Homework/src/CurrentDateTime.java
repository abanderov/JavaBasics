import java.util.Date;
public class CurrentDateTime {
	public static void main(String[] args) {
		Date today = new Date();
		System.out.println(today);
	}

}
