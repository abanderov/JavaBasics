import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class SortArrayOfStrings {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		List<String> allCities = new ArrayList<String>();
		for (int i = 0; i <= n; i++) {
			String city = input.nextLine();
			allCities.add(city);
		}
		input.close();
		String[] arrayCities = new String[allCities.size()];
		arrayCities = allCities.toArray(arrayCities);
		arraySort(arrayCities);
		for (String string : arrayCities) {
			System.out.println(string);
		}
	}
	static String[] arraySort(String[] array){
		for (int i = 0; i < array.length - 1; i++) {
			int minIndex = i;
			for (int j = i+1; j < array.length; j++) {
				if (array[j].compareTo(array[minIndex]) < 0) {
					minIndex = j;
				}
			}
			String temp = array[i];
			array[i] = array[minIndex];
			array[minIndex] = temp;
		}
		return array;
	}
}
