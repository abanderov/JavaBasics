import java.util.Scanner;
public class SumTwoNumbers {
	public static void main(String[] args) {
		int firstNumber, secondNumber, sum;
		Scanner input = new Scanner(System.in);
		//System.out.println("Enter first number: ");
		firstNumber = input.nextInt();
		//System.out.println("Enter second number: ");
		secondNumber = input.nextInt();
		input.close();
		sum = firstNumber + secondNumber;
		System.out.println(sum);
	}
}
