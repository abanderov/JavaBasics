import java.util.*;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.FontSelector;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class DeckOfCards {
	private static String FILE = "DeckOfCards.pdf";
	private static List<String> cards = new ArrayList<String>();
	public static void main(String[] args) {
		for (int i = 2; i < 15; i++) {
			String cardNumber = "";
			cardNumber = "" + i;
			if (i > 10) {
				switch (cardNumber) {
				case "11": cardNumber = "J";
					break;
				case "12": cardNumber = "Q";
					break;
				case "13": cardNumber = "K";
					break;
				case "14": cardNumber = "A";
					break;
				}
			}
			cards.add(cardNumber);
		}

		//System.out.println(completeDeckSpades +"\n\n" + completeDeckHearts + "\n\n" + completeDeckDiamonds + "\n\n" + completeDeckClubs);
		try {
		      Document document = new Document();
		      PdfWriter.getInstance(document, new FileOutputStream(FILE));
		      document.open();
		      document.add(createTable());
		      document.close();
		    } 
		catch (Exception e) {
		      e.printStackTrace();
		    }
	}
	private static PdfPTable createTable() throws DocumentException, IOException {
			BaseFont unicode = BaseFont.createFont("UKIJSlsTom.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); 
		    PdfPTable table = new PdfPTable(13);
		    Font red = new Font(unicode);
		    red.setColor(BaseColor.RED);
		    FontSelector fsNormal = new FontSelector();
		    FontSelector fsRed = new FontSelector();
	        fsNormal.addFont(new Font(unicode));
	        fsRed.addFont(new Font(red));
		    PdfPCell cell;
		    cell = new PdfPCell();
	        cell.setRowspan(52);
	        table.setSpacingBefore(7);
	        table.setSpacingAfter(7);
		    for (int i = 0; i < 4; i++) {
				if (i == 0) {
					for (int j = 0; j < cards.size(); j++) {
						//completeDeckSpades += (cards.get(j) + "♠" + " ");
						cell = new PdfPCell(fsNormal.process(cards.get(j) + "\u2660"));
						cell.setFixedHeight(42f);
						cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						table.addCell(cell);
					}
				}
				if (i == 1) {
					for (int j = 0; j < cards.size(); j++) {
						//completeDeckHearts += (cards.get(j) + "♥" + " ");
						cell = new PdfPCell(fsRed.process(cards.get(j) + "\u2665"));
						cell.setFixedHeight(42f);
						cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						table.addCell(cell);
					}
				}
				if (i == 2) {
					for (int j = 0; j < cards.size(); j++) {
						//completeDeckDiamonds += (cards.get(j) + "♦" + " ");
						cell = new PdfPCell(fsRed.process(cards.get(j) + "\u2666"));
						cell.setFixedHeight(42f);
						cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						
						table.addCell(cell);
					}
				}
				if (i == 3) {
					for (int j = 0; j < cards.size(); j++) {
						//completeDeckClubs += (cards.get(j) + "♣" + " ");
						cell = new PdfPCell(fsNormal.process(cards.get(j) + "\u2663"));
						cell.setFixedHeight(42f);
						cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
						table.addCell(cell);
					}
				}
			}

		    return table;
  }
}
